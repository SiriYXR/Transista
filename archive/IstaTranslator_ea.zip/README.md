# IstaTranslator
 A translator base on Pythonista
